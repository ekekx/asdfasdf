
## jedol5_server.py --> 서버 파일, 이 파일을 열고 실행합니다. 

### app.py --> 연습용
